EE2003 assignment 3a submission by Anand Uday Gokhale, EE17B158
The modules RF, ALU,Decoder,Imem and Dmem are drawn as boxes in the block diagram. Everthing else on the block diagram(Basically Muxes, Latches, PC and an AND gate) are a part of the CPU.

Please use the dmem I have provided to avoid issues, I have slight modifications to it(improving byte addressability) that make it compatible with the rest of my code. I did this because it improved my modularity, and made it easier to debug my code.


